from policyholder import Policyholder
from product import Product
from payment import Payment

# Create policyholders
policyholder1 = Policyholder(policyholder_id=1, name="Chukwuemeka Chikelu")
policyholder2 = Policyholder(policyholder_id=2, name="Margaret Kalu")

# Register policyholders
policyholder1.register()
policyholder2.register()

# Create a product
product = Product(product_id=1, name="Travel Insurance", price=50000)

# Create payments
payment1 = Payment(payment_id=1, policyholder_id=1, product_id=1, amount=50000)
payment2 = Payment(payment_id=2, policyholder_id=2, product_id=1, amount=50000)

# Process payments
payment1.process_payment()
payment2.process_payment()

# Display policyholder details
print(f"Policyholder 1: {policyholder1.name}, Status: {policyholder1.status}")
print(f"Policyholder 2: {policyholder2.name}, Status: {policyholder2.status}")