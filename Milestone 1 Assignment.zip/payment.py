class Payment:
    def __init__(self, payment_id, policyholder_id, product_id, amount):
        #Initialize a new payment.
        #payment_id: Unique identifier for the payment.
        #policyholder_id: Unique identifier for the policyholder making the payment.
        #product_id: Unique identifier for the product being paid for.
        #amount: Amount of the payment.        
        self.payment_id = payment_id
        self.policyholder_id = policyholder_id
        self.product_id = product_id
        self.amount = amount

    def process_payment(self):
        #Process the payment.
        print(f"Payment of {self.amount} has been processed for policyholder {self.policyholder_id}.")

    def send_reminder(self):
        #Send a payment reminder to the policyholder.
        print(f"Reminder sent to policyholder {self.policyholder_id}.")

    def apply_penalty(self, penalty_amount):
        #Apply a penalty to the payment amount.
        #penalty_amount: Amount of the penalty to be added.
        self.amount += penalty_amount
        print(f"Penalty of {penalty_amount} applied. New amount is {self.amount}.")