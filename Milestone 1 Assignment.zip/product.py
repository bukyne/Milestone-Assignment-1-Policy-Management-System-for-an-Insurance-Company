class Product:
    def __init__(self, product_id, name, price):
        #Initialize a new product.
        #product_id: Unique identifier for the product.
        #name: Name of the product.
        #price: Price of the product.
        self.product_id = product_id
        self.name = name
        self.price = price

    def create(self):
        #Create the product.
        print(f"Product {self.name} has been created.")

    def update(self, name, price):
        #Update the product details.
        #name: New name of the product.
        #price: New price of the product.      
        self.name = name
        self.price = price
        print(f"Product {self.product_id} has been updated.")

    def remove(self):
        #Remove the product.
        print(f"Product {self.name} has been removed.")